#This is the final project of TCSS558 Applied distributed computing.

#Title: A Distributed Geospatial Sensor Networks

#Team Member:	Jiacheng liu  (Server, Geospatial Database, Data Synthesis)
			 	PingHan Lei   (Client, Visualization, Server)


#Please refer to the ppt for the description ,structure of the code.

#run 'python XML_Server.py' to start servers

#run 'python XML_Server.py' to start clients

#open 'heatmap.html' in any browser to check the result
